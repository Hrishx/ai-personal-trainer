'use client'

import { useState } from 'react'
import WorkoutSelection from '@/components/screens/WorkoutSelection'
import ExerciseDemo from '@/components/screens/ExerciseDemo'
import LiveCoaching from '@/components/screens/LiveCoaching'
import WorkoutSummary from '@/components/screens/WorkoutSummary'

type Screen = 'selection' | 'demo' | 'coaching' | 'summary'

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('selection')
  const [selectedExercise, setSelectedExercise] = useState<string | null>(null)

  const handleSelectExercise = (exercise: string) => {
    setSelectedExercise(exercise)
    setCurrentScreen('demo')
  }

  const handleStartCoaching = () => {
    setCurrentScreen('coaching')
  }

  const handleFinishWorkout = () => {
    setCurrentScreen('summary')
  }

  const handleRestartWorkout = () => {
    setCurrentScreen('selection')
    setSelectedExercise(null)
  }

  return (
    <div className="w-full min-h-screen bg-background">
      {currentScreen === 'selection' && (
        <WorkoutSelection onSelectExercise={handleSelectExercise} />
      )}
      {currentScreen === 'demo' && selectedExercise && (
        <ExerciseDemo
          exercise={selectedExercise}
          onStartCoaching={handleStartCoaching}
        />
      )}
      {currentScreen === 'coaching' && selectedExercise && (
        <LiveCoaching
          exercise={selectedExercise}
          onFinishWorkout={handleFinishWorkout}
        />
      )}
      {currentScreen === 'summary' && selectedExercise && (
        <WorkoutSummary
          exercise={selectedExercise}
          onRestart={handleRestartWorkout}
        />
      )}
    </div>
  )
}
