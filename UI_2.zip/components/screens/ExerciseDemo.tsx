'use client'

import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ChevronLeft } from 'lucide-react'
import { useState } from 'react'

interface ExerciseDemoProps {
  exercise: string
  onStartCoaching: () => void
}

const exerciseInstructions: Record<string, string[]> = {
  'Squat': [
    'Keep chest upright and shoulders back',
    'Knees aligned with toes',
    'Lower hips below knee level',
    'Push through heels to return to start',
  ],
  'Push-up': [
    'Hands shoulder-width apart',
    'Body in straight line from head to heels',
    'Lower chest toward floor',
    'Push back to starting position',
  ],
  'Lunge': [
    'Step forward with one leg',
    'Lower hips until both knees at 90 degrees',
    'Keep front knee aligned over ankle',
    'Push back to starting position',
  ],
  'Plank': [
    'Hands under shoulders, body in straight line',
    'Core engaged, no sagging hips',
    'Keep neck neutral',
    'Hold position for desired duration',
  ],
}

export default function ExerciseDemo({ exercise, onStartCoaching }: ExerciseDemoProps) {
  const [animationFrame, setAnimationFrame] = useState(0)

  // Simulate animation progression
  const animateFrame = () => {
    setAnimationFrame((prev) => (prev + 1) % 4)
  }

  return (
    <div className="min-h-screen w-full bg-background px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-8 flex items-center gap-4">
          <button className="rounded-full border border-border bg-card p-2 hover:bg-muted transition-colors soft-shadow">
            <ChevronLeft className="h-6 w-6 text-foreground" />
          </button>
          <h1 className="text-3xl font-bold text-foreground">Learn the Movement</h1>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Demo Animation Area */}
          <Card className="flex h-96 items-center justify-center border border-border bg-gradient-to-br from-primary/5 to-secondary/5 overflow-hidden soft-shadow-md">
            <div className="relative w-full h-full flex items-center justify-center">
              {/* Placeholder animation */}
              <div className="flex flex-col items-center gap-6">
                <div className="text-6xl animate-bounce">{['🦵', '💪', '🦵', '⭐'][['Squat', 'Push-up', 'Lunge', 'Plank'].indexOf(exercise)]}</div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-2">Movement Demo</p>
                  <p className="text-xl font-semibold text-primary">Frame {animationFrame + 1} of 4</p>
                </div>
                <button
                  onClick={animateFrame}
                  className="mt-4 px-4 py-2 rounded-full bg-primary/15 text-primary hover:bg-primary/25 transition-colors text-sm font-semibold"
                >
                  Next Frame
                </button>
              </div>
            </div>
          </Card>

          {/* Instructions */}
          <div className="flex flex-col justify-between">
            <div>
              <h2 className="mb-4 text-2xl font-bold text-foreground">{exercise}</h2>

              {/* Step-by-step Instructions */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary">Step-by-Step Instructions:</h3>
                <div className="space-y-3">
                  {exerciseInstructions[exercise]?.map((instruction, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary/15 text-sm font-bold text-primary">
                        {index + 1}
                      </div>
                      <p className="text-sm text-card-foreground leading-relaxed pt-1">
                        {instruction}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Key Tips */}
              <div className="mt-8 rounded-2xl border border-secondary/20 bg-secondary/10 p-4">
                <p className="text-sm font-semibold text-secondary mb-2">💡 Key Tips:</p>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Keep movements controlled and smooth</li>
                  <li>• Maintain proper form over speed</li>
                  <li>• Engage your core throughout</li>
                </ul>
              </div>
            </div>

            {/* Start Button */}
            <Button
              onClick={onStartCoaching}
              className="mt-8 w-full bg-gradient-to-r from-primary to-secondary text-white hover:shadow-lg py-6 text-lg font-semibold soft-shadow-md"
            >
              Start Live Coaching
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
