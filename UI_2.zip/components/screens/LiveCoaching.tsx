'use client'

import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { CheckCircle2, AlertCircle } from 'lucide-react'
import { useState, useEffect } from 'react'

interface LiveCoachingProps {
  exercise: string
  onFinishWorkout: () => void
}

const feedbackMessages: Record<string, string[]> = {
  'Squat': [
    'Keep your knees aligned with your toes.',
    'Lower your hips further for full range of motion.',
    'Excellent form! Keep going.',
    'Straighten your back slightly.',
  ],
  'Push-up': [
    'Lower your body more slowly for control.',
    'Great form! Continue.',
    'Keep your elbows close to your body.',
    'Perfect rep! Well done.',
  ],
  'Lunge': [
    'Ensure your front knee stays over your ankle.',
    'Beautiful lunge! Keep it up.',
    'Back knee should almost touch the ground.',
    'Excellent balance!',
  ],
  'Plank': [
    'Engage your core more.',
    'Great hold! Maintain this position.',
    'Keep your hips level.',
    'Outstanding form!',
  ],
}

const detectedErrors: Record<string, string[]> = {
  'Squat': ['Knee Valgus', 'Forward Lean', 'Shallow Depth'],
  'Push-up': ['Sagging Hips', 'Elbows Flared', 'Incomplete Range'],
  'Lunge': ['Knee Caving', 'Excessive Lean', 'Uneven Depth'],
  'Plank': ['Sagging Hips', 'Head Drop', 'Shoulder Roll'],
}

export default function LiveCoaching({ exercise, onFinishWorkout }: LiveCoachingProps) {
  const [reps, setReps] = useState(0)
  const [formScore, setFormScore] = useState(82)
  const [currentFeedback, setCurrentFeedback] = useState(feedbackMessages[exercise][0])
  const [workoutTime, setWorkoutTime] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setWorkoutTime((prev) => prev + 1)
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const handleRepComplete = () => {
    setReps((prev) => prev + 1)
    const messages = feedbackMessages[exercise]
    setCurrentFeedback(messages[Math.floor(Math.random() * messages.length)])
    setFormScore(Math.max(70, formScore - Math.random() * 5))
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div className="min-h-screen w-full bg-background px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        {/* Live Camera Panel */}
        <div className="mb-8 overflow-hidden rounded-3xl border-2 border-primary bg-card soft-shadow-lg">
          <div className="relative aspect-video w-full bg-gradient-to-br from-primary/5 to-secondary/5 flex items-center justify-center overflow-hidden">
            {/* Camera Placeholder */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-8xl mb-4 animate-pulse">📹</div>
                <p className="text-muted-foreground">Live Camera Feed</p>
              </div>
            </div>

            {/* Top-Left Overlay */}
            <div className="absolute top-6 left-6 bg-white/90 backdrop-blur rounded-2xl px-4 py-3 border border-border shadow-md">
              <p className="text-xs text-muted-foreground mb-1 font-semibold">EXERCISE</p>
              <p className="text-xl font-bold text-primary mb-3">{exercise}</p>
              <div className="space-y-2">
                <p className="text-sm"><span className="text-muted-foreground">Reps:</span> <span className="text-primary font-bold">{reps}</span></p>
                <p className="text-sm"><span className="text-muted-foreground">Phase:</span> <span className="text-secondary font-bold">Concentric</span></p>
              </div>
            </div>

            {/* Top-Right Overlay - Rep Completion */}
            <div className="absolute top-6 right-6 bg-white/90 backdrop-blur rounded-2xl px-4 py-3 border border-border text-center shadow-md">
              <p className="text-xs text-muted-foreground mb-2 font-semibold">REP STATUS</p>
              <CheckCircle2 className="h-8 w-8 text-primary mx-auto animate-pulse" />
              <p className="text-xs text-primary mt-2 font-semibold">Ready</p>
            </div>

            {/* Bottom Overlay - Form Score */}
            <div className="absolute bottom-6 left-6 right-6 bg-white/90 backdrop-blur rounded-2xl px-4 py-3 border border-border shadow-md">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground mb-1 font-semibold">FORM SCORE</p>
                  <p className="text-2xl font-bold text-primary">{formScore.toFixed(0)}%</p>
                </div>
                <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-500"
                    style={{ width: `${formScore}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid gap-4 sm:grid-cols-4 mb-8">
          <Card className="bg-card border-border p-6 soft-shadow">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Total Reps</p>
            <p className="text-4xl font-bold text-primary">{reps}</p>
          </Card>
          <Card className="bg-card border-border p-6 soft-shadow">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Form Score</p>
            <p className="text-4xl font-bold text-secondary">{formScore.toFixed(0)}%</p>
          </Card>
          <Card className="bg-card border-border p-6 soft-shadow">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Fatigue</p>
            <p className="text-4xl font-bold text-primary">{(reps * 8).toFixed(0)}%</p>
          </Card>
          <Card className="bg-card border-border p-6 soft-shadow">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Time</p>
            <p className="text-4xl font-bold text-foreground">{formatTime(workoutTime)}</p>
          </Card>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Coach Feedback Panel */}
          <div className="lg:col-span-2">
            <Card className="bg-card border-secondary/30 p-6 soft-shadow-md">
              <div className="mb-4 flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-secondary animate-pulse" />
                <h3 className="font-semibold text-secondary">AI Coach Feedback</h3>
              </div>
              <p className="text-lg text-card-foreground mb-6">{currentFeedback}</p>
              <Button
                onClick={handleRepComplete}
                className="w-full bg-gradient-to-r from-primary to-secondary text-white hover:shadow-lg py-3 font-semibold soft-shadow"
              >
                Complete Rep
              </Button>
            </Card>
          </div>

          {/* Detected Errors */}
          <Card className="bg-card border-border p-6 soft-shadow">
            <div className="mb-4 flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-accent" />
              <h3 className="font-semibold text-accent">Common Issues</h3>
            </div>
            <div className="space-y-3">
              {detectedErrors[exercise].map((error, index) => (
                <div key={index} className="flex items-start gap-3 rounded-xl bg-accent/10 p-3 border border-accent/20">
                  <div className="h-2 w-2 rounded-full bg-accent mt-1.5 flex-shrink-0" />
                  <p className="text-sm text-card-foreground">{error}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="mt-8 flex gap-4">
          <Button
            onClick={onFinishWorkout}
            className="flex-1 bg-destructive text-destructive-foreground hover:bg-destructive/90 py-3 font-semibold soft-shadow"
          >
            Finish Workout
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-border bg-card text-foreground hover:bg-muted py-3 font-semibold soft-shadow"
          >
            Pause
          </Button>
        </div>
      </div>
    </div>
  )
}
