'use client'

import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Dumbbell } from 'lucide-react'

interface WorkoutSelectionProps {
  onSelectExercise: (exercise: string) => void
}

const exercises = [
  {
    name: 'Squat',
    difficulty: 'Intermediate',
    muscleGroup: 'Legs',
    icon: '🦵',
  },
  {
    name: 'Push-up',
    difficulty: 'Beginner',
    muscleGroup: 'Chest',
    icon: '💪',
  },
  {
    name: 'Lunge',
    difficulty: 'Intermediate',
    muscleGroup: 'Legs',
    icon: '🦵',
  },
  {
    name: 'Plank',
    difficulty: 'Beginner',
    muscleGroup: 'Core',
    icon: '⭐',
  },
]

export default function WorkoutSelection({ onSelectExercise }: WorkoutSelectionProps) {
  return (
    <div className="min-h-screen w-full bg-background px-4 py-12 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-16 text-center">
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="rounded-full bg-gradient-to-br from-primary to-secondary p-3">
              <Dumbbell className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-5xl font-bold tracking-tight text-foreground sm:text-6xl">
            AI Fitness <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">Coach</span>
          </h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Choose your workout and let AI guide your form
          </p>
        </div>

        {/* Exercise Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {exercises.map((exercise) => (
            <Card
              key={exercise.name}
              className="group relative overflow-hidden border border-border bg-card transition-all duration-300 hover:shadow-lg soft-shadow cursor-pointer"
            >
              <div
                onClick={() => onSelectExercise(exercise.name)}
                className="flex h-full w-full flex-col p-6"
              >
                {/* Icon Area */}
                <div className="mb-4 flex items-center justify-center rounded-2xl bg-primary/10 py-8">
                  <span className="text-5xl">{exercise.icon}</span>
                </div>

                {/* Content */}
                <div className="flex flex-1 flex-col text-left">
                  <h3 className="text-xl font-bold text-card-foreground mb-2">
                    {exercise.name}
                  </h3>

                  {/* Difficulty */}
                  <div className="mb-3">
                    <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${
                      exercise.difficulty === 'Beginner'
                        ? 'bg-primary/15 text-primary'
                        : exercise.difficulty === 'Intermediate'
                          ? 'bg-secondary/15 text-secondary'
                          : 'bg-destructive/15 text-destructive'
                    }`}>
                      {exercise.difficulty}
                    </span>
                  </div>

                  {/* Muscle Group */}
                  <p className="text-sm text-muted-foreground mb-4 flex-1">
                    Target: <span className="text-primary font-semibold">{exercise.muscleGroup}</span>
                  </p>
                </div>

                {/* Start Button */}
                <button className="w-full mt-4 bg-primary text-white font-semibold py-2 rounded-full hover:bg-primary/90 transition-colors soft-shadow">
                  Start →
                </button>
              </div>
            </Card>
          ))}
        </div>

        {/* Footer Info */}
        <div className="mt-16 rounded-2xl border border-border bg-primary/5 p-6 text-center soft-shadow">
          <p className="text-sm text-muted-foreground">
            💡 <span className="text-card-foreground font-semibold">Pro Tip:</span> Ensure you have adequate space and your camera is set up before starting
          </p>
        </div>
      </div>
    </div>
  )
}
