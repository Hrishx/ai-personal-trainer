'use client'

import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Trophy, TrendingUp, AlertTriangle, Heart } from 'lucide-react'

interface WorkoutSummaryProps {
  exercise: string
  onRestart: () => void
}

export default function WorkoutSummary({ exercise, onRestart }: WorkoutSummaryProps) {
  const stats = {
    totalReps: 24,
    avgFormScore: 84,
    fatigueLevel: 72,
    detectedErrors: ['Shallow Depth', 'Forward Lean'],
  }

  return (
    <div className="min-h-screen w-full bg-background px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="mb-6 flex items-center justify-center">
            <Trophy className="h-16 w-16 text-primary animate-bounce" />
          </div>
          <h1 className="text-5xl font-bold mb-3 text-foreground">Workout Complete!</h1>
          <p className="text-xl text-muted-foreground">
            Great job! Here's your AI coaching analysis for <span className="text-primary font-semibold">{exercise}</span>
          </p>
        </div>

        {/* Performance Metrics */}
        <div className="grid gap-4 sm:grid-cols-4 mb-12">
          <Card className="bg-card border-border p-6 text-center soft-shadow">
            <p className="text-sm font-semibold text-muted-foreground uppercase mb-2">Total Reps</p>
            <p className="text-4xl font-bold text-primary mb-2">{stats.totalReps}</p>
            <p className="text-xs text-muted-foreground">+3 from last session</p>
          </Card>
          <Card className="bg-card border-border p-6 text-center soft-shadow">
            <p className="text-sm font-semibold text-muted-foreground uppercase mb-2">Form Score</p>
            <p className="text-4xl font-bold text-secondary mb-2">{stats.avgFormScore}%</p>
            <p className="text-xs text-muted-foreground">+5% improvement</p>
          </Card>
          <Card className="bg-card border-border p-6 text-center soft-shadow">
            <p className="text-sm font-semibold text-muted-foreground uppercase mb-2">Fatigue</p>
            <p className="text-4xl font-bold text-primary mb-2">{stats.fatigueLevel}%</p>
            <p className="text-xs text-muted-foreground">Moderate intensity</p>
          </Card>
          <Card className="bg-card border-border p-6 text-center soft-shadow">
            <p className="text-sm font-semibold text-muted-foreground uppercase mb-2">Duration</p>
            <p className="text-4xl font-bold text-foreground mb-2">8:42</p>
            <p className="text-xs text-muted-foreground">Well paced</p>
          </Card>
        </div>

        {/* AI Coaching Report */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold mb-6 text-foreground">AI Coaching Report</h2>

          {/* Performance Overview */}
          <Card className="bg-card border-border p-6 soft-shadow-md">
            <div className="mb-4 flex items-center gap-3">
              <TrendingUp className="h-6 w-6 text-primary" />
              <h3 className="text-lg font-bold text-primary">Performance Overview</h3>
            </div>
            <p className="text-card-foreground leading-relaxed">
              Excellent performance today! You completed {stats.totalReps} reps with an average form score of {stats.avgFormScore}%. Your consistency is improving, and you're maintaining proper technique throughout the set. The intensity level was well-balanced, allowing you to maintain control while building strength and endurance.
            </p>
          </Card>

          {/* Rep Mistakes */}
          <Card className="bg-card border-border p-6 soft-shadow">
            <div className="mb-4 flex items-center gap-3">
              <AlertTriangle className="h-6 w-6 text-accent" />
              <h3 className="text-lg font-bold text-accent">Form Corrections Needed</h3>
            </div>
            <div className="space-y-3">
              {stats.detectedErrors.map((error, index) => (
                <div key={index} className="rounded-2xl bg-accent/10 border border-accent/20 p-4">
                  <p className="font-semibold text-accent mb-1">{error}</p>
                  <p className="text-sm text-card-foreground">
                    {error === 'Shallow Depth'
                      ? "Try to lower your hips more to achieve a full range of motion. This will increase muscle engagement and improve long-term strength gains."
                      : "Keep your torso more upright. A forward lean shifts weight to your knees. Focus on leading with your chest."}
                  </p>
                </div>
              ))}
            </div>
          </Card>

          {/* Injury Prevention */}
          <Card className="bg-card border-border p-6 soft-shadow">
            <div className="mb-4 flex items-center gap-3">
              <Heart className="h-6 w-6 text-secondary" />
              <h3 className="text-lg font-bold text-secondary">Injury Prevention</h3>
            </div>
            <p className="text-card-foreground leading-relaxed">
              Your form remained stable throughout the workout. The detected form issues were minor and easily correctable. To prevent injury, focus on maintaining neutral spine alignment and avoiding rapid movements. Consider incorporating flexibility work and progressive overload in future sessions.
            </p>
          </Card>

          {/* Motivational Feedback */}
          <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20 p-6 soft-shadow-md">
            <h3 className="text-lg font-bold text-card-foreground mb-3">⭐ Great Work!</h3>
            <p className="text-card-foreground leading-relaxed mb-4">
              You're showing steady improvement. Your form consistency has improved by 5% compared to your last session. Keep up this momentum, and you'll reach your fitness goals in no time. Challenge yourself to add 2 more reps in your next session!
            </p>
            <div className="mt-4 p-4 rounded-xl bg-primary/15 border border-primary/20">
              <p className="text-sm font-semibold text-primary mb-2">Next Session Recommendation:</p>
              <p className="text-sm text-card-foreground">Try increasing volume by 2 reps or adding an extra set to progressively overload your muscles.</p>
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="mt-12 flex flex-col gap-4 sm:flex-row">
          <Button
            onClick={onRestart}
            className="flex-1 bg-gradient-to-r from-primary to-secondary text-white hover:shadow-lg py-6 text-lg font-semibold soft-shadow-md"
          >
            Start Another Workout
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-border bg-card text-foreground hover:bg-muted py-6 text-lg font-semibold soft-shadow"
          >
            View Full History
          </Button>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center p-6 rounded-2xl bg-primary/5 border border-border soft-shadow">
          <p className="text-sm text-muted-foreground">
            Keep training consistently for best results. Your AI coach is learning your form patterns to provide even better guidance.
          </p>
        </div>
      </div>
    </div>
  )
}
