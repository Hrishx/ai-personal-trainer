import requests
import threading


class CoachLLMEngine:

    def __init__(self):

        # Model
        self.model = "qwen2.5:3b-instruct"

        # Ollama API
        self.url = "http://localhost:11434/api/chat"

        self.latest_response = None
        self.lock = threading.Lock()

        self.running = False

    # ==========================================
    # LLM WARMUP
    # ==========================================

    def warmup(self):

        try:

            print("Warming up LLM...")

            requests.post(
                self.url,
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "user", "content": "hello"}
                    ],
                    "options": {
                        "num_predict": 20
                    },
                    "stream": False
                },
                timeout=60
            )

            print("LLM Ready")

        except Exception as e:

            print("LLM warmup failed:", e)

    # ==========================================
    # REQUEST SUMMARY
    # ==========================================

    def request_set_summary(self, summary_data, user_profile):

        if self.running:
            return

        self.running = True

        thread = threading.Thread(
            target=self._generate_set_summary,
            args=(summary_data, user_profile)
        )

        thread.daemon = True
        thread.start()

    # ==========================================
    # FORMAT REP DATA
    # ==========================================

    def _format_rep_data(self, rep_data):

        lines = []

        for rep in rep_data:

            line = (
                f"Rep {rep['rep']} | "
                f"Score: {rep['quality_score']} | "
                f"Knee: {rep['knee']} | "
                f"Back: {rep['back']} | "
                f"Depth: {rep['depth']} | "
                f"Fatigue: {rep['fatigue']}"
            )

            lines.append(line)

        return "\n".join(lines)

    # ==========================================
    # FORMAT REP ANALYSIS
    # ==========================================

    def _format_rep_analysis(self, analysis):

        if isinstance(analysis, list):
            return "\n".join(analysis)

        return str(analysis)

    # ==========================================
    # GENERATE REPORT
    # ==========================================

    def _generate_set_summary(self, summary_data, user_profile):

        try:

            rep_data_text = self._format_rep_data(summary_data["rep_data"])

            rep_analysis_text = self._format_rep_analysis(
                summary_data.get("rep_analysis", [])
            )

            prompt = f"""
You are an AI strength coach analyzing a squat workout.

Workout Summary
Total reps: {summary_data['total_reps']}

Rep-by-Rep Analysis:
{rep_analysis_text}

Detailed Rep Data:
{rep_data_text}

Injury Risks:
{summary_data.get('injury_risks', [])}

Write a SHORT coaching report.

Include:
1. Performance overview
2. Rep mistakes
3. Form correction advice
4. Injury warning
5. Motivation

Limit response to under 150 words.
"""

            print("Sending request to Ollama...")

            response = requests.post(
                self.url,
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "user", "content": prompt}
                    ],
                    "options": {
                        "num_predict": 200
                    },
                    "stream": False
                },
                timeout=180
            )

            if response.status_code != 200:

                print("LLM ERROR:", response.text)
                self.running = False
                return

            data = response.json()

            message = data["message"]["content"]

            with self.lock:
                self.latest_response = message

            print("LLM response received")

        except Exception as e:

            print("LLM ERROR:", e)

        self.running = False

    # ==========================================
    # GET RESPONSE
    # ==========================================

    def get_latest_message(self):

        with self.lock:

            msg = self.latest_response
            self.latest_response = None

        return msg